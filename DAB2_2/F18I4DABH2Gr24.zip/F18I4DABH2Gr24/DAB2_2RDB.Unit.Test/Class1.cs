﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DAB2_2RDB.Unit.Test
{
    class Class1
    {
    }
}
