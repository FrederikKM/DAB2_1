using System;
using Xunit;

namespace DAB2_2_RDB.Integration.Test
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
