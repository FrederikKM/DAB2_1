﻿namespace DAB2_2RDB.Models
{
    public class AddressName : BaseEntity
    {
        public string StreetName { get; set; }
        public string HouseNumber { get; set; }
    }
}