﻿namespace DAB2_2RDB
{
    public class BaseEntity
    {
        public int Id { get; set; }
    }
}