﻿namespace F18I4DABH2Gr24Lib
{
    public class ZipCode
    {
        public string Zip { get; set; }
        public City CityName { get; set; }

        public CountryCode CountryCode { get; set; }
    }
}