﻿
namespace F18I4DABH2Gr24Lib
{
    public class City
    {
        public string Name { get; set; }
        public ZipCode ZipCode { get; set; }
    }
}