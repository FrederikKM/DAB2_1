﻿using System.Collections.Generic;

namespace F18I4DABH2Gr24Lib
{
    public class AddressType
    {
        public string Type { get; set; }

        public Address Address { get; set; }
        public List<Person> Persons { get; set; }
    }
}