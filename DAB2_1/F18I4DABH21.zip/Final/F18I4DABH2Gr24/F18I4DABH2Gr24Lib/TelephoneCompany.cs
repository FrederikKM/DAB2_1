﻿using System.Collections.Generic;

namespace F18I4DABH2Gr24Lib
{
    public class TelephoneCompany
    {
        public List<TelephoneNumber> TelephoneNumbers { get; set; }
        public string Company { get; set; }
    }
}