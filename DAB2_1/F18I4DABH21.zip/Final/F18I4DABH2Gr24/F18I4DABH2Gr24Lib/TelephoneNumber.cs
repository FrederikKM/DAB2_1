﻿namespace F18I4DABH2Gr24Lib
{
    public class TelephoneNumber
    {
        public string Number { get; set; }
        public string Use { get; set; }
    }
}