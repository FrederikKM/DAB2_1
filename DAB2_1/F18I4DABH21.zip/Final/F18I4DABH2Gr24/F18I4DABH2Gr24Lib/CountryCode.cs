﻿namespace F18I4DABH2Gr24Lib
{
    public class CountryCode
    {
        public string Code { get; set; }
    }
}